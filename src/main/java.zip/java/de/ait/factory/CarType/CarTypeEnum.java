package de.ait.factory.CarType;

/**
 * @author Andrej Reutow
 * created on 15.07.2023
 */
public enum CarTypeEnum {
    SPORT,
    SUV,
    BUDGET,
    CHILD,
}
